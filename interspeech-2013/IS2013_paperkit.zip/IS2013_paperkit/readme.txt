General instructions for all authors on creating PDFs.

Authors who use Adobe software to create their PDFs should use the joboptions files available at:

http://www.causalproductions.com/authors/causal_job_options_20080427v3.zip 

so that the created PDF files are suitable for publication.

Note that authors using non-Adobe software to create the PDFs must work out their own settings (in particular to ensure
all fonts are embedded) to obtain suitable PDFs.

All Authors must proofread their PDF file prior to submission to ensure it is correct.  Author's should not rely on 
proof-reading the WORD file -- please proofread the PDF file before it is submitted.